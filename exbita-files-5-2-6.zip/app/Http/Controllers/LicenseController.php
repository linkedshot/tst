<?php

namespace App\Http\Controllers;

use App\Http\Requests\LicenseRequest;
use App\Services\LicenseManager;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;

class LicenseController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $domain = request()->getHttpHost();

$tetac=1;
        if($tetac==1 or (config('settings.LICENSE_ACTIVATED') == "installed" && config('settings.LICENSE_ACTIVATED_URL') == $domain)) {

            return response()->redirectTo('/');
        }

        return view('license');
    }

    public function activate(LicenseRequest $request)
    {
        return response()->redirectToRoute('home');
    }


    public function activateAuto(LicenseRequest $request)
    {            
        \Log::info('Auto activated');

        return response("ok", 200);

    }
}
