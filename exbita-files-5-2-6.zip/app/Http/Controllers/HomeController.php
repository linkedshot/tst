<?php

namespace App\Http\Controllers;

use App\Helpers\SiteSettingsHelper;
use App\Models\Locale;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Validator;

class HomeController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mainTheme = config('settings.MAIN_THEME');

        return view($mainTheme.'.index')
            ->with('admin', false);
    }
}
