<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ApplicationStateController extends Controller
{
    /**
     * Check connection with Ethereum Node
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if(config('settings.APPLICATION_STATE') == "synced") {
            return response()->redirectTo('/installed.html');
        } else if(config('settings.APPLICATION_STATE') == "error"){
            return view('application-state-error');
        }

        return view('application-state');
    }
}
