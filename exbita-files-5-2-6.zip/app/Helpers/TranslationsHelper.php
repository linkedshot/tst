<?php

namespace App\Helpers;

use App\Models\Locale;

class TranslationsHelper
{
    public static function getTranslationsString($locale, $admin)
    {

    }

    public static function getLocales()
    {
        return Locale::select(['locale', 'name'])->get();
    }

    public static function translationAllowedTags($string)
    {
        return strip_tags($string, '<br><table><tr><th><td><a><div><span>');
    }
}
