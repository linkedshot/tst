<?php

namespace App\Helpers;

use Illuminate\Support\Facades\Schema;

class SiteSettingsHelper
{
    public static $settingsLoaded = false;

    public static $configMap = [
        //App config
        'app.name' => 'SITE_NAME',
        'app.url' => 'SITE_URL',
        'app.copyright' => 'SITE_COPYRIGHT',

        //Email config
        'mail.driver' => 'MAIL_MAILER',
        'mail.host' => 'MAIL_HOST',
        'mail.port' => 'MAIL_PORT',
        'mail.username' => 'MAIL_USERNAME',
        'mail.password' => 'MAIL_PASSWORD',
        'mail.from.address' => 'MAIL_FROM_ADDRESS',
        'mail.from.name' => 'MAIL_FROM_NAME',
        'mail.encryption' => 'MAIL_ENCRYPTION',

        //Bitcoin config
        'bitcoind.default.user' => 'BITCOIND_USER',
        'bitcoind.default.password' => 'BITCOIND_PASSWORD',
        'bitcoind.default.host' => 'BITCOIND_HOST',
        'bitcoind.default.port' => 'BITCOIND_PORT',
        'blockchain.bitcoin_confirmations' => 'BITCOIND_CONFIRMATIONS_REQUIRED',

        //AWS S3 assets bucket conf
        'filesystems.disks.s3.key' => 'S3_KEY',
        'filesystems.disks.s3.secret' => 'S3_SECRET',
        'filesystems.disks.s3.region' => 'S3_REGION',
        'filesystems.disks.s3.bucket' => 'S3_BUCKET',

        //AWS S3 backup bucket conf
        'filesystems.disks.s3b.key' => 'S3_KEY',
        'filesystems.disks.s3b.secret' => 'S3_SECRET',
        'filesystems.disks.s3b.region' => 'S3_REGION',
        'filesystems.disks.s3b.bucket' => 'S3_BUCKET_BACKUP',

        //Google Recaptcha conf
        'captcha.secret' => 'NOCAPTCHA_SECRET',
        'captcha.sitekey' => 'NOCAPTCHA_SITEKEY',
    ];

    public static function loadSettings()
    {
        /*
         * We need to check if site settings table exists before loading them .
         *
         * Since we load the settings in service provider, initial php artisan migrate command on first deploy phase and
         * and phpunit test runs fails when site_settings table is missing. During tests and initial setup, values in the .env file are going to be used instead.
         */
        if (! Schema::hasTable('site_settings')) {
            return;
        }

        if (self::$settingsLoaded) {
            return;
        }

        $settings = SiteSettings::all()->pluck('sensitive', 'name')->all();

        $values = [];

        foreach (self::$configMap as $key => $name) {
            if (isset($settings[$name]) && strlen(trim($settings[$name])) > 0) {
                //if the value is set via .env file and it is now set via db config, keep using the value in .env file
                //this is required for the initial setup should work properly and
                //it is also required to use the config values from .env file running phpunit tests.
                if (isset($_ENV[$name]) && ! empty($_ENV[$name]) && empty($settings[$name])) {
                    continue;
                }
                $values[$key] = $settings[$name];
            }
        }

        self::$settingsLoaded = true;
    }

    public static function getPublicSettings()
    {
        $keys = [
            'SITE_NAME',
            'SITE_URL',
            'SITE_LOGO',
            'SITE_LOGO_FAVICON',
            'SITE_LOGO_INVERT',
            'SITE_CONTACT_EMAIL',
            'SITE_COPYRIGHT',
            'SOCIAL_FACEBOOK_URL',
            'DISABLE_IYZICO_CREDIT_CARD_PAYMENT',
            'DISABLE_PAYPAL_PAYMENT',
            'SHOW_COIN_INFO_PAGE',
            'ENABLE_TOKEN_PAGE',
            'QUOTE_CURRENCY',
            'SOCIAL_TWITTER_USERNAME',
            'SOCIAL_TELEGRAM_USERNAME',
            'SOCIAL_INSTAGRAM_USERNAME',
            'GOOGLE_TAG_MANAGER_CONTAINER_ID',
            'STRIPE_KEY',
            'ENABLE_STRIPE_PAYMENT',
        ];

        $settings = SiteSettings::select([
            'name',
            'value',
            'type',
            'extra_data',
        ])->whereIn('name', $keys)->get();

        $map = [];
        foreach ($settings as $setting) {
            $map[$setting->name] = [
                'value' => $setting->value,
                'file_url' => $setting->file_url,
            ];
        }

        foreach ($keys as $key) {
            //Check if config is found in DB,
            if (! isset($map[$key])) {
                //Search for existing values coming from .env file
                $configPath = array_search($key, self::$configMap);

                if ($configPath !== false && config($configPath, 'no-value' !== 'no-value')) {
                    //use that value if exists
                    $map[$key] = [
                        'value' => config($configPath),
                        'file_url' => null,
                    ];
                } //Use empty values if not exists
                else {
                    $map[$key] = [
                        'value' => null,
                        'file_url' => null,
                    ];
                }
            }
        }

        return $map;
    }

    public static function get($key)
    {
        $setting = SiteSettings::where('name', $key)->first();
        if ($setting) {
            return [
                'value' => $setting->sensitive,
                'file_url' => $setting->file_url,
            ];
        } else {
            return [
                'value' => '',
                'file_url' => '',
            ];
        }
    }







}
