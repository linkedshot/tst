<?php

namespace App\Console\Commands;

use App\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AdminCreateCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'exbita:create-admin';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create Initial Admin User';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        \Log::info('admin create update');
        $this->info('admin create update');
        $name = $this->validateInputs('name', 'What is your name?', 'required|string|min:2|max:30');
        \Log::info('admin create update 2');
        $this->info('admin create update 2');
        $email = trim($this->validateInputs('email', 'Please enter your email', 'required|string|min:2|max:30|email'));
        $password_confirmation = trim($this->validateInputs('password_confirmation', 'Please enter your password', 'required|string|min:8|strong_password'));
        $password = trim($this->validateInputs('password', 'Please confirm your password', 'required|string|min:8|strong_password|confirmed', $password_confirmation));

        // Create user
        $user = User::create([
            'name' => $name,
            'email' => $email,
            'password' => Hash::make($password),
            'verify_token' => User::generateToken(),
            'locale' => App::getLocale(),
            'status' => 1,
            'id_verified' => 1,
        ]);

        // Assign admin role
        $user->assignRoles('admin');

        // Admin Access
        $user->givePermissionTo('access.admin');

        // Set env to production & clear cache & install missing wallets
        Artisan::call('config:clear');
        Artisan::call('user:addMissingWallets');

        $this->info('Initial admin user was created successfully. You can login now with the following credentials:');
        \Log::info('Initial admin user was created successfully. You can login now with the following credentials:');

        $this->warn('Name: '.$name);
        $this->warn('Email: '.$email);
        $this->warn('Password: '.$password);
        $this->warn('Login url: '.config('app.url').'/login');

    }

    protected function validateInputs($field, $ask, $rules, $confirmation = false)
    {
        do {
            $data[$field] = trim($this->ask($ask));

            if ($confirmation) {
                $data[$field.'_confirmation'] = $confirmation;
            }

            $validator = Validator::make($data, [$field => $rules]);

            if ($validator->fails()) {
                $message = $validator->getMessageBag()->toArray();
                foreach ($message[$field] as $error) {
                    $this->error($error);
                }
            }
        } while ($validator->fails());

        return $data[$field];
    }
}
