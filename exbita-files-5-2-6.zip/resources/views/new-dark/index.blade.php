<!doctype html>
<html lang="en">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Exbita</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <meta name="author" content="Gitesoft">



    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">

    <link rel="stylesheet" href="/css/vendor.css">

    <link rel="stylesheet" href="/css/app.css">
    <link rel="icon" href="/favicon.jpg">

</head>

<body>


<div id="app"></div>

</body>
</html>

