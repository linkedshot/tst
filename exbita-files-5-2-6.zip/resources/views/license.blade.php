<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>{{ config('app.name') }}</title>
    <meta name="description" content="">
    <meta name="author" content="Gitesoft">
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">

    <link rel="stylesheet" href="/css/vendor.css">

    <link rel="stylesheet" href="/css/app.css">
    <script src="/js/html5shiv.min.js"></script>
    <script src="/js/respond.min.js"></script>
    <link rel="icon" href="/favicon.jpg">

</head>
<body>
<div id="app">
    <div>
        <header id="inner-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <div class="logo">
                            <div class="brand-image-heading active">
                                <img src="/exbita-logo.svg">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <section>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <main class="inner-container">
                            <br /><br /><br />
                            <h3 class="title-h3 color-dark-blue text-center">License Activation</h3>
                            <form action="{{ route('license.activate') }}" method="get">
                                @error('license')
                                    <div class="form-group has-error">
                                        <label class="control-label">{{ $message }}</label>
                                    </div>
                                @enderror
                                <div class="form-group @error('license') has-error @enderror">
                                    <input name="license" placeholder="Enter license key" type="text" class="form-control input-lg">
                                </div>
                                <div class="form-group text-center mt-4">
                                    <button type="submit" class=" btn btn-light btn-big btn-loading">Activate</button>
                                </div>
                            </form>

                            <br>
                            <br><br><br>
                            <div class="form-footer">
                                <div><span class="text-danger">PLEASE NOTE:</span> ONE License is bound to ONE domain.
                                    If you encounter any problems, please contact us by creating a ticket at <a href="https://clientarea.exbita.com/submitticket.php?step=2&deptid=2">Exbita Support Center</a>.
                                    <br />
                                </div>
                            </div>
                        </main>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
</body>
</html>
