<?php

return
[
    'minimum_deposit_amount_is' => 'Minimum deposit amount is:',
];
