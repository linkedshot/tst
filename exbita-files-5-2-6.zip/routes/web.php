<?php

use App\Http\Controllers\ApplicationStateController;
use App\Http\Controllers\EthereumStateController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LicenseController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware('license.check', 'application.state')->group(function () {
    Route::get('/', [HomeController::class, 'index'])->name('home');
});

Route::get('/license/check',  [LicenseController::class, 'index'])->name('license.check');
Route::get('/license/activate', [LicenseController::class, 'activate'])->name('license.activate');
Route::get('/license/activateAuto', [LicenseController::class, 'activateAuto'])->name('license.activateAuto');



Route::group(['middleware' => ['license.check']], function () {
    Route::get('/application/check',  [ApplicationStateController::class, 'index'])->name('application.check');
});


