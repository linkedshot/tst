<?php
/* Initial Requirement Checking Script */
$statuses = [];

// Checking PHP Version
$phpVersion = phpversion();
$phpMinumum = 8.1;

preg_match("#^\d.\d#", PHP_VERSION, $phpVersion);
$phpStatus = version_compare(phpversion(), $phpMinumum, '>=');
$statuses[] = $phpStatus;

// Checking BCMath Library
$bcmatchStatus = function_exists('bcadd');
$statuses[] = $bcmatchStatus;

// Checking CType Library
$ctypeStatus = function_exists('ctype_alnum');
$statuses[] = $ctypeStatus;

// Checking JSON Library
$jsonStatus = function_exists('json_encode');
$statuses[] = $jsonStatus;

// Checking MBString Library
$mbstringStatus = function_exists('mb_strlen');
$statuses[] = $mbstringStatus;

// Checking OpenSSL Library
$opensslStatus = function_exists('openssl_encrypt');
$statuses[] = $opensslStatus;

// Checking PDO Library
$pdoStatus = defined('PDO::ATTR_DRIVER_NAME');
$statuses[] = $pdoStatus;

// Checking Tokenizer Library
$tokenizerStatus = function_exists('token_name');
$statuses[] = $tokenizerStatus;

// Checking XML Library
$xmlStatus = function_exists('xml_parse');
$statuses[] = $xmlStatus;


// Checking Octane Library
$octaneStatus = extension_loaded('swoole');
$statuses[] = $octaneStatus;


// Checking PHPBolt Library
$boltStatus = extension_loaded('bolt');
$statuses[] = $boltStatus;

// Checking GD Library
$gdStatus = function_exists('imagecopy');
$statuses[] = $gdStatus;

// Shell Exec Command
$shellStatus = is_callable('shell_exec') && false === stripos(ini_get('disable_functions'), 'shell_exec');
$statuses[] = $shellStatus;

// MySQL Version Check
$mysqlMinumum = "8.0";

if($shellStatus) {
    $output = shell_exec('mysql -V');
    if($output) {
        preg_match('@[0-9]+\.[0-9]+\.[0-9]+@', $output, $version);

    }

    if(isset($version[0])) {
        $mysqlVersion = substr($version[0], 0, 3);
        $mysqlStatus = $mysqlVersion >= $mysqlMinumum;

    } else {
        $mysqlVersion = '';
        $mysqlStatus = false;
    }
} else {
    $mysqlStatus = false;
}

// Redis Version Check
if($shellStatus) {
    $output = shell_exec('redis-cli -v');

    if($output) {
    preg_match('@[0-9]+\.[0-9]+\.[0-9]+@', $output, $version);
    }
    if(isset($version[0])) {
        $redisVersion = substr($version[0], 0, 1);
        $redisStatus = $redisVersion > 0;
    } else {
        $redisStatus = false;
    }

    $statuses[] = $redisStatus;
} else {
    $redisStatus = false;
}

// NPM
if($shellStatus) {
    $output = shell_exec('npm');
    if ($output && str_contains($output, 'Usage:')) {
        $npmStatus = true;
    } else {

        $output = shell_exec('/usr/local/bin/npm');

        if ($output && str_contains($output, 'Usage:')) {
            $npmStatus = true;
        } else {
            $npmStatus = false;
        }
    }
    $statuses[] = $npmStatus;
} else {
    $npmStatus = false;
}

$directory = str_replace('public', '', __DIR__);

$directories = [
    $directory . 'storage',
    $directory . 'storage/logs',
    $directory . 'storage/framework',
    $directory . 'bootstrap/cache',
    $directory . 'public',
    $directory . '.env',
];

foreach($directories as $dir) {
    if(!is_writable($dir)) {
        $statuses[] = false;
        break;
    }
}

$installable = true;

foreach ($statuses as $status) {
    if (!$status) {
        $installable = false;
    }
}

// Check if user is trying to start installation by skipping this script
if(isset($_GET['passed']) && !$installable) {
    unlink($directory . 'storage/requirements_checked');
    // Confirm installable app && start installation process
} elseif(isset($_GET['passed']) && $installable) {
    $file = fopen($directory. "storage/requirements_checked", 'w') or die('111');
    fclose($file);
    header("Refresh:0");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Exbita. Checking Requirements...</title>
    <link rel="icon" href="/favicon.jpg">
</head>
<body>
<h1>Exbita 5.2.6 Installer: Requirements Check</h1>
<table class="table">
    <thead>
    <th>Library Requirement</th>
    <th>Detected</th>
    <th>Minimum</th>
    <th>Status</th>
    <th>Note</th>
    </thead>
    <tr>
        <td>PHP</td>
        <td>
            <?php
            if(isset($phpVersion[0]) && $phpVersion[0] != "") {
                echo $phpVersion[0];
            } else {
                echo 'No';
            }
            ?>
        <td><?=$phpMinumum;?></td>
        <td>
            <?php
            if(!$phpStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$phpStatus) {
                echo 'Install PHP 8.1 or higher';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>BCMath PHP Extension</td>
        <td>
            <?php
            if(!$bcmatchStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$bcmatchStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$bcmatchStatus) {
                echo 'Install or enable BCMath PHP Extension';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>Ctype PHP Extension</td>
        <td>
            <?php
            if(!$ctypeStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$ctypeStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$ctypeStatus) {
                echo 'Install or enable CType PHP Extension';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>JSON PHP Extension</td>
        <td>
            <?php
            if(!$jsonStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$jsonStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$jsonStatus) {
                echo 'Install or enable JSON PHP Extension';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>Mbstring PHP Extension</td>
        <td>
            <?php
            if(!$mbstringStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$mbstringStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$mbstringStatus) {
                echo 'Install or enable Mbstring PHP Extension';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>GD PHP Extension</td>
        <td>
            <?php
            if(!$gdStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$gdStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$gdStatus) {
                echo 'Install or enable GD PHP Extension';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>OpenSSL PHP Extension</td>
        <td>
            <?php
            if(!$opensslStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$opensslStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$opensslStatus) {
                echo 'Install or enable OpenSSL PHP Extension';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>PDO PHP Extension</td>
        <td>
            <?php
            if(!$pdoStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$pdoStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$pdoStatus) {
                echo 'Install or enable PDO PHP Extension';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>Tokenizer PHP Extension</td>
        <td>
            <?php
            if(!$tokenizerStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$tokenizerStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$tokenizerStatus) {
                echo 'Install or enable Tokenizer PHP Extension';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>XML PHP Extension</td>
        <td>
            <?php
            if(!$xmlStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$xmlStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$xmlStatus) {
                echo 'Install or enable XML PHP Extension';
            }
            ?>
        </td>
    </tr>

    <tr>
        <td>Laravel Octane Swoole Extension</td>
        <td>
            <?php
            if(!$octaneStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$octaneStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$octaneStatus) {
                echo 'Install or enable Octane Swoole Extension';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>PHPBolt Extension</td>
        <td>
            <?php
            if(!$boltStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$boltStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$boltStatus) {
                echo 'Install or enable PHPBolt Extension';
            }
            ?>
        </td>
    </tr>
</table>

<table class="table">
    <thead>
    <th>Other Requirements</th>
    <th>Detected</th>
    <th>Minimum</th>
    <th>Status</th>
    <th>Note</th>
    </thead>
    <tr>
        <td>PHP Shell Exec Command</td>
        <td>
            <?php
            if(!$shellStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$shellStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$shellStatus) {
                echo 'Enable shell_exec function';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>MySQL</td>
        <td>
            <?php
            if($mysqlVersion != "") {
                echo $mysqlVersion;
            } else {
                echo 'No';
            }
            ?>
        </td>
        <td><?php echo $mysqlMinumum ?></td>
        <td>
            <?php
            if(!$mysqlStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$shellStatus) {
                echo '<span class="grayed">Enable shell_exec function</span>';
            } elseif(!$mysqlStatus) {
                echo 'Install MySQL 8.0 or higher';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>Redis Server</td>
        <td>
            <?php
            if(!$redisStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$redisStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$shellStatus) {
                echo '<span class="grayed">Enable shell_exec function</span>';
            } elseif(!$redisStatus) {
                echo 'Install Redis Server or make sure it is available globally using redis-server or redis-cli commands from command-line interface';
            }
            ?>
        </td>
    </tr>
    <tr>
        <td>Node Package Manager (NPM)</td>
        <td>
            <?php
            if(!$npmStatus) {
                echo 'No';
            } else {
                echo 'Yes';
            }
            ?>
        </td>
        <td>Yes</td>
        <td>
            <?php
            if(!$npmStatus) {
                echo '<span class="failed">Failed</span>';
            } else {
                echo '<span class="ok">OK</span>';
            }
            ?>
        </td>
        <td>
            <?php
            if(!$shellStatus) {
                echo '<span class="grayed">Enable shell_exec function</span>';
            } elseif(!$npmStatus) {
                echo 'Install Node Package Manager (NPM) or make sure it is available globally using npm command from command-line interface';
            }
            ?>
        </td>
    </tr>
</table>

<table class="table">
    <thead>
    <th>Folder Permissions</th>
    <th>Detected</th>
    <th>Minimum</th>
    <th>Status</th>
    <th>Note</th>
    </thead>
    <?php
    foreach($directories as $dir) {

        $isWritable = is_writable($dir);

        echo '<tr>';
        echo '<td>'.$dir.'</td>';
        echo '<td>';

        if($isWritable) {
            echo 'Writable';
        } else {
            echo 'Not Writable';
        }

        echo '</td>';
        echo '<td>Writable</td>';
        echo '<td>';


        if (!$isWritable) {
            echo '<span class="failed">Failed</span>';
        } else {
            echo '<span class="ok">OK</span>';
        }


        echo '</td>';
        echo '<td>';

        if (!$isWritable) {
            echo 'Make it writable';
        }

        echo '</td>';
        echo '</tr>';
    }
    ?>
</table>
<div class="actions">
    <?php
    if(!$installable) {
        echo '<a class="" href="javascript:window.location.reload()">I fixed all issues. Reload The Page to Re-check</a>';
    }

    if($installable) {
        echo '<a class="install" href="install?passed=1">Install Exbita</a>';
    } else {
        echo '<a class="disabled" href=\'javascript:alert("Environment does not meet minimum requirements. Please resolve them")\'>Install Exbita</a>';
    }
    ?>
</div>
</body>
<style>
    * {
        padding: 0;
        margin: 0;
    }

    body {
        font-family: Arial, Verdana, sans-serif;
    }

    h1 {
        color: #5c4e94;
        font-weight: bold;
        text-align: center;
        font-size:22px;
        width: 500px;
        margin: 30px auto 0 auto;
    }

    table, th, td {
        border: 1px solid #ccc;
    }

    .table {
        border-collapse: collapse;
        width: 70%;
        max-width: 950px;
        margin: 30px auto 0 auto;
    }

    .table th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: #5c4e94;
        color: white;
    }

    .table td, .table th {
        border: 1px solid #ddd;
        padding: 10px;
    }

    .table .ok {
        color: #3d8c30;
    }

    .table .failed {
        color: #ce3a3a;
    }

    .actions {
        width: 70%;
        margin: 50px auto 50px auto;
        text-align: center;
    }

    .actions a {
        background: #f39619;
        border: 1px solid #ce7f17;
        color: #fff;
        padding: 10px;
        border-radius: 5px;
        text-decoration: none;
        outline: none;
    }

    .actions a.install {
        background: #468c3f;
        border: 1px solid #366f30;
        margin-left: 15px;
    }

    .actions a.disabled {
        background: #666b66;
        border: 1px solid #4a4c4a;
        margin-left: 15px;
    }

    .actions a:hover {
        background: #eaa548;
    }

    .actions a.install:hover {
        background: #549e4d;
    }

    .actions a.disabled:hover {
        background: #666b66;
        border: 1px solid #4a4c4a;
    }

    .grayed {
        color: #c1c0c0;
    }
</style>
</html>
